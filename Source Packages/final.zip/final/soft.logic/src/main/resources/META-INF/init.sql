
CREATE DATABASE isis4710db;
GRANT ALL PRIVILEGES ON isis4710db.* TO 'root'@'localhost' WITH GRANT OPTION;	
flush privileges;
